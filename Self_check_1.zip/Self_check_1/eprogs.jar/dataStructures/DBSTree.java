

/** binary search tree with duplicates */

package dataStructures;

public interface DBSTree extends BSTree
   {}
