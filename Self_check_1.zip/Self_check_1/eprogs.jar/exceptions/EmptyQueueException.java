

package exceptions;

public class EmptyQueueException
       extends RuntimeException
{
   public EmptyQueueException()
      {super();}
}
