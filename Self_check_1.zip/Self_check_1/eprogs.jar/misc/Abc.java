


package misc;

public class Abc
{
   public static int abc(int a, int b, int c)
      {return a+b+b*c+(a+b-c)/(a+b)+4;}
   
   public static void main(String [] args)
      {System.out.println(abc(2,3,4));}
}
