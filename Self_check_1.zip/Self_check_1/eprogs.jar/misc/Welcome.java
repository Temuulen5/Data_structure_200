

/** Welcome to the book */

package misc;

public class Welcome
{
   public static void main(String [] args)
   {
      System.out.println("Welcome to the text Data Structures,");
      System.out.println("Algorithms, and Applications in Java");
      System.out.println("by Sartaj Sahni");
      System.out.println("Hope you enjoy the text.");
   }
}
