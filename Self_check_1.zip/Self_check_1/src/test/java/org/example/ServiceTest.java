package org.example;

import org.junit.jupiter.api.Test;

class ServiceTest {

    @Test
    void sayHello() {
    }
}